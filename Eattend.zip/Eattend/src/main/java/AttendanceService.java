import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

public class AttendanceService {

    public void markAttendance(int studentId) {
        String otp = OTPGenerator.generateOTP();
        LocalDate date = LocalDate.now();

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO attendance (student_id, date, otp, status) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, studentId);
            stmt.setDate(2, java.sql.Date.valueOf(date));
            stmt.setString(3, otp);
            stmt.setString(4, "Pending");
            stmt.executeUpdate();
            System.out.println("Attendance marked with OTP: " + otp);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean verifyOTP(int studentId, String otp) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM attendance WHERE student_id = ? AND otp = ? AND status = 'Pending'";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, studentId);
            stmt.setString(2, otp);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String updateSql = "UPDATE attendance SET status = 'Present' WHERE attendance_id = ?";
                PreparedStatement updateStmt = conn.prepareStatement(updateSql);
                updateStmt.setInt(1, rs.getInt("attendance_id"));
                updateStmt.executeUpdate();
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
