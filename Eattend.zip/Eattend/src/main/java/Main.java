import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        AttendanceService service = new AttendanceService();
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter your Student ID: ");
        int studentId = sc.nextInt();
        sc.nextLine();  // consume newline

        try {
            String qrData = "StudentID:" + studentId;
            QRCodeGenerator.generateQRCode(qrData, "student_qr.png");
            System.out.println("QR Code generated successfully: student_qr.png");

            service.markAttendance(studentId);

            System.out.print("Enter the OTP displayed/generated: ");
            String otp = sc.nextLine();

            if (service.verifyOTP(studentId, otp)) {
                System.out.println("Attendance confirmed!");
            } else {
                System.out.println("Invalid OTP. Attendance failed.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        sc.close();
    }
}
